{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    Minecraft Player Manager
@endsection

@section('content-header')
    <h1>Player Manager</h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li>@lang('navigation.server.configuration')</li>
        <li class="active">Player Manager</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Player List</h3>
                </div>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody>
                            <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                            @foreach ($data as $item)
                                <tr>
                                    <td><img src="https://minotar.net/helm/{{ $item['player'] }}/30.png"> {{ $item['player'] }}</td>
                                    <td>
                                        <span class="label label-success">Online</span>
                                    </td>
                                    <td class="text-center">
                                        <form method="post" action="{{ route('server.players.command', $server->uuidShort) }}" style="display: inline-block;">
                                            <input name="command" type="text" value="op {{ $item['player'] }}" class="hidden">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-success">Make Operator</button>
                                        </form>
                                        <form method="post" action="{{ route('server.players.command', $server->uuidShort) }}" style="display: inline-block;">
                                            <input name="command" type="text" value="kick {{ $item['player'] }}" class="hidden">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-warning">Kick Player</button>
                                        </form>
                                        <form method="post" action="{{ route('server.players.command', $server->uuidShort) }}" style="display: inline-block;">
                                            <input name="command" type="text" value="ban {{ $item['player'] }}" class="hidden">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-danger">Ban Player</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('js/frontend/server.socket.js') !!}
@endsection
