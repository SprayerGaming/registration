<?php

namespace Pterodactyl\Http\Controllers\Server;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Traits\Controllers\JavascriptInjection;
use Pterodactyl\Contracts\Repository\Daemon\PowerRepositoryInterface;
use Pterodactyl\Repositories\Daemon\PlayersRepository;
use Illuminate\Support\Facades\DB;

class PlayerController extends Controller
{
    use JavascriptInjection;

    /**
     * @var \Pterodactyl\Contracts\Repository\Daemon\PowerRepositoryInterface
     */
    private $powerRepository;

    /**
     * @var \Pterodactyl\Contracts\Repository\Daemon\PlayersRepositoryInterface
     */
    private $playersRepository;

    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    /**
     * Worlds constructor.
     *
     * @param AlertsMessageBag $alert
     * @param worldsRepository $worldsRepository
     */
    public function __construct(
      AlertsMessageBag $alert,
      PowerRepositoryInterface $powerRepository,
      PlayersRepository $playersRepository
    ) {
        $this->alert = $alert;
        $this->powerRepository = $powerRepository;
        $this->playersRepository = $playersRepository;
    }

    public function index(Request $request): View
    {
        $server = $request->attributes->get('server');

        $ip = $server->allocation->ip .':'. $server->allocation->port;
        $json = file_get_contents('https://api.mcsrvstat.us/1/'. $ip);
        $obj = json_decode($json);

        $data = [];

        if ($obj->players->online > 0) {
            foreach ($obj->players->list as $player) {
               array_push($data, [
                 'player' => $player
               ]);
            }
        }

        return view('server.players.index', ['data' => $data, 'server' => $server]);
    }

    public function command(Request $request)
    {
        $server = $request->attributes->get('server');

        echo $request->input('command');

        $command = $this->playersRepository->setServer($server)->send_custom([
          'command' => $request->input('command')
        ]);

        return redirect()->back();
    }

    public function operators(Request $request)
    {
        $server = $request->attributes->get('server');
        $operators = $this->playersRepository->setServer($server)->operators([]);

        if (json_decode($operators->getBody())->success != "true") {
            $error = json_decode($folders->getBody())->error;
            $names = null;
        } else {
            $data = json_decode($operators->getBody())->name;
            $obj = json_decode($data, true);
            $error = false;
            $names = [];

            foreach ($obj as $name) {
                array_push($names, [
                  'name' => $name['name']
                ]);
            }
        }

        return view('server.players.operators', [
          'names' => $names,
          'error' => $error,
          'data' => $data
        ]);
    }

    public function bans(Request $request)
    {
        $server = $request->attributes->get('server');
        $bans = $this->playersRepository->setServer($server)->bans([]);

        if (json_decode($bans->getBody())->success != "true") {
            $error = json_decode($folders->getBody())->error;
            $names = null;
        } else {
            $data = json_decode($bans->getBody())->name;
            $obj = json_decode($data, true);
            $error = false;
            $names = [];

            foreach ($obj as $name) {
                array_push($names, [
                  'name' => $name['name'],
                  'expires' => $name['expires'],
                  'reason' => $name['reason']
                ]);
            }
        }

        return view('server.players.bans', [
          'names' => $names,
          'error' => $error,
          'data' => $data
        ]);
    }

    public function unban(Request $request)
    {
        $server = $request->attributes->get('server');
        $bans = $this->playersRepository->setServer($server)->bans([]);

        if (json_decode($bans->getBody())->success != "true") {
            $error = json_decode($folders->getBody())->error;
            $names = null;
        } else {
            $data = json_decode($bans->getBody())->name;
            $obj = json_decode($data, true);
            $error = false;

            foreach ($obj as $name) {
                 $this->playersRepository->setServer($server)->send_custom([
                  'command' => 'pardon '. $name['name']
                ]);
            }
        }

        return redirect()->back();
    }
}
