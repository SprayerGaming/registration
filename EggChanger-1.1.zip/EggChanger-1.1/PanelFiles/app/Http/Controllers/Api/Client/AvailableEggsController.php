<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Exceptions\DisplayException;

class AvailableEggsController extends ClientApiController
{
    /**
     * @param Request $request
     * @return array
     */
    public function index(Request $request): array
    {
        $eggs = [];
        $available_eggs = DB::table('available_eggs')->get();

        foreach ($available_eggs as $available_egg) {
            $egg = DB::table('eggs')->where('id', '=', $available_egg->egg_id)->get();
            array_push($eggs, $egg[0]);
        }

        return [
            'success' => true,
            'data' => [
                'eggs' => $eggs,
            ],
        ];
    }
}
