<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Illuminate\Validation\ValidationException;
use Illuminate\Auth\Access\AuthorizationException;
use Pterodactyl\Services\Servers\ReinstallServerService;
use Pterodactyl\Exceptions\Model\DataValidationException;
use Pterodactyl\Services\Servers\StartupModificationService;
use Pterodactyl\Exceptions\Repository\RecordNotFoundException;
use Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException;
use Pterodactyl\Http\Requests\Api\Client\Servers\EggChangerRequest;

class EggChangerController extends ClientApiController
{

    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    protected $alert;

    /**
     * @var \Pterodactyl\Services\Servers\StartupModificationService
     */
    protected $startupModificationService;

    /**
     * @var \Pterodactyl\Services\Servers\ReinstallServerService
     */
    protected $reinstallServerService;

    /**
     * RustWipeController constructor.
     * @param AlertsMessageBag $alert
     * @param ReinstallServerService $reinstallServerService
     * @param StartupModificationService $startupModificationService
     */
    public function __construct(AlertsMessageBag $alert, ReinstallServerService $reinstallServerService, StartupModificationService $startupModificationService)
    {
        $this->alert = $alert;
        $this->reinstallServerService = $reinstallServerService;
        $this->startupModificationService = $startupModificationService;
    }

    /**
     * @param Request $request
     * @return View
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function index(EggChangerRequest $request, Server $server): array
    {

        $selectable_eggs = [];
        $installedEgg = DB::table('servers')->select('egg_id')->where('id', '=', $server->id)->get();

        foreach (unserialize($server->available_eggs) as $item) {
            $egg = DB::table('eggs')->where('id', '=', $item)->get();
            array_push($selectable_eggs, $egg[0]);
        }

        return [
            'success' => true,
            'data' => [
                'installedEgg' => $installedEgg,
                'eggs' => $selectable_eggs
            ],
        ];

    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function change(EggChangerRequest $request, Server $server): array
    {

        $id = (int) $request->input('id');

        $egg = DB::table('eggs')->where('id', '=', $id)->get();
        if (count($egg) < 1) {
            throw new DisplayException('Egg not found');
        }

        $available = DB::table('available_eggs')->where('egg_id', '=', $id)->get();
        if (count($available) < 1) {
            throw new DisplayException('This egg isn\'t available to this server.');
        }

        $available_eggs = unserialize($server->available_eggs);
        if (!in_array($id, $available_eggs)) {
            throw new DisplayException('This egg isn\'t available to this server.');
        }

        $this->startupModificationService->setUserLevel(User::USER_LEVEL_ADMIN);
        try {
            $this->startupModificationService->handle($server, [
                'nest_id' => $egg[0]->nest_id,
                'egg_id' => $egg[0]->id,
            ]);
        } catch (ValidationException $e) {
            $error = $e->getMessage();
        } catch (DaemonConnectionException $e) {
            $error = $e->getMessage();
        } catch (DataValidationException $e) {
            $error = $e->getMessage();
        } catch (RecordNotFoundException $e) {
            $error = $e->getMessage();
        }

        if (isset($error)) {
            throw new DisplayException('Failed to change the egg');
        }

        try {
            $this->reinstallServerService->handle($server);
        } catch (\Throwable $e) {
            throw new DisplayException('Failed to reinstall server. Please reinstall it manually.');
        }

        return [
            'success' => true,
            'data' => [],
        ];
    }
}
