import http from '@/api/http';
import { EggsResponse } from '@/components/server/eggchanger/EggChangerContainer';

export default async (uuid: string): Promise<EggsResponse> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/eggchanger`);

    return (data.data || []);
};
