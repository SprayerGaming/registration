import http from '@/api/http';
import { EggsResponse } from '@/components/dashboard/eggs/EggsContainer';

export default async (): Promise<EggsResponse> => {
    const { data } = await http.get('/api/client/eggs');
    return (data.data || []);
};
