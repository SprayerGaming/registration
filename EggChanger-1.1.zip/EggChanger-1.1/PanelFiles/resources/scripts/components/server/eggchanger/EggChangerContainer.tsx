import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import tw from 'twin.macro';
import useSWR from 'swr';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import Spinner from '@/components/elements/Spinner';
import getEggs from '@/api/server/eggchanger/getEggs';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Button from '@/components/elements/Button';
import { faPuzzlePiece } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import ChangeButton from '@/components/server/eggchanger/ChangeButton';

export interface EggsResponse {
    eggs: any[];
    installedEgg: any[];
}

export default () => {
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid);

    const { clearFlashes, clearAndAddHttpError } = useFlash();

    const { data, error, mutate } = useSWR<EggsResponse>([ uuid, '/eggchanger' ], (uuid) => getEggs(uuid), {
        revalidateOnFocus: false,
    });

    useEffect(() => {
        if (!error) {
            clearFlashes('server:eggchanger');
        } else {
            clearAndAddHttpError({ key: 'server:eggchanger', error });
        }
    }, [ error ]);

    return (
        <ServerContentBlock title={'Egg Changer'} css={tw`flex flex-wrap`}>
            <div css={tw`w-full`}>
                <FlashMessageRender byKey={'server:eggchanger'} css={tw`mb-4`} />
            </div>
            {!data ?
                <div css={tw`w-full`}>
                    <Spinner size={'large'} centered />
                </div>
                :
                <>
                    {data.eggs.length < 1 ?
                        <div css={tw`w-full`}>
                            <p css={tw`text-center text-sm text-neutral-400 pt-4 pb-4`}>
                                There are no eggs for this server.
                            </p>
                        </div>
                        :
                        (
                            <>
                                {data.eggs.map((item, key) => (
                                    <div css={tw`w-full lg:w-4/12 lg:pl-4`} key={key}>
                                        <TitledGreyBox title={item.name}>
                                            <div css={tw`px-1 py-2`}>
                                                {item.thumbnail !== null ?
                                                <div css={tw`w-full pt-4`}>
                                                    <img src={item.thumbnail} css={tw`w-full pt-4`} />
                                                </div>
                                                : null
                                                }
                                                <span>{item.description.substr(0, 200) + (item.description.length > 200 ? '...' : '')}</span>
                                                <div css={tw`flex justify-end text-right`}>
                                                    {item.id === data.installedEgg[0]?.egg_id ?
                                                    <Button size={'xsmall'} color={'grey'}>Installed</Button>
                                                    : <ChangeButton id={item.id} installed={() => mutate()}></ChangeButton>
                                                    }
                                                </div>
                                            </div>
                                        </TitledGreyBox>
                                        <br></br>
                                    </div>
                                ))}
                            </>
                        )
                    }
                </>
            }
        </ServerContentBlock>
    );
};
