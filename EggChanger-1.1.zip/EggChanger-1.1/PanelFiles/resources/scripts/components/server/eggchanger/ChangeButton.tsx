import React, { useState } from 'react';
import Button from '@/components/elements/Button';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { ServerContext } from '@/state/server';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDownload, faRedo } from '@fortawesome/free-solid-svg-icons';
import changeEgg from '@/api/server/eggchanger/changeEgg';
import { httpErrorToHuman } from '@/api/http';
import ConfirmationModal from '@/components/elements/ConfirmationModal';
import tw from 'twin.macro';

interface Props {
    id: string;
    installed: () => any;
}

export default ({ id, installed }: Props) => {
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid);

    const [ visible, setVisible ] = useState(false);
    const [ isLoading, setIsLoading ] = useState(false);
    const { addError, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const onInstall = () => {
        setIsLoading(true);
        clearFlashes('server:eggchanger');

        changeEgg(uuid, id)
            .then(() => {
                setIsLoading(false);
                setVisible(false);
                installed();
            })
            .catch(error => {
                addError({ key: 'server:eggchanger', message: httpErrorToHuman(error) });
                setIsLoading(false);
                setVisible(false);
            });
    };

    return (
        <>
            <ConfirmationModal
                visible={visible}
                title={'Change egg?'}
                buttonText={'Yes'}
                onConfirmed={onInstall}
                showSpinnerOverlay={isLoading}
                onModalDismissed={() => setVisible(false)}
            >
                Are you sure you want to Change egg for this server?
                When you change egg the server will reinstalled and all files will deleted
            </ConfirmationModal>
            <Button color={'green'} size={'xsmall'} onClick={() => setVisible(true)}>
                <FontAwesomeIcon icon={faDownload} /> Install
            </Button>
        </>
    );
};