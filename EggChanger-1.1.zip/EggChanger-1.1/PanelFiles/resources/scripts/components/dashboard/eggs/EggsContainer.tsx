import React, { useEffect, useState } from 'react';
import PageContentBlock from '@/components/elements/PageContentBlock';
import tw from 'twin.macro';
import FlashMessageRender from '@/components/FlashMessageRender';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import useSWR from 'swr';
import { Link } from 'react-router-dom';
import Button from '@/components/elements/Button';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import MessageBox from '@/components/MessageBox';

import getEggs from '@/api/eggs/getEggs';

export interface EggsResponse {
    eggs: any[];
}

export default () => {
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { data, error } = useSWR<EggsResponse>([ '/eggs' ], () => getEggs());


    useEffect(() => {
        if (!error) {
            clearFlashes('eggs');
        } else {
            clearAndAddHttpError({ key: 'eggs', error });
        }
    });

    return (
        <PageContentBlock title={'Eggs'} css={tw`flex flex-wrap`}>
            <div css={tw`w-full`}>
                <FlashMessageRender byKey={'eggs'} css={tw`mb-4`} />
            </div>
            {!data ?
                <div css={tw`w-full`}>
                    <Spinner size={'large'} centered />
                </div>
                :
                <>
                    {data.eggs.length < 1 ?
                      <div css={tw`w-full`}>
                            <MessageBox type="info" title="Info">
                                There are no eggs.
                            </MessageBox>
                        </div>
                        :
                        (data.eggs.map((item, key) => (
                            <div css={tw`w-full lg:w-4/12 lg:pl-4`} key={key}>
                                <TitledGreyBox title={item.name}>
                                    <div css={tw`px-1 py-2`}>
                                        {item.thumbnail !== null ?
                                        <div css={tw`w-full pt-4`}>
                                            <img src={item.thumbnail} css={tw`w-full pt-4`} />
                                        </div>
                                        : null
                                        }
                                        <span>{item.description.substr(0, 200) + (item.description.length > 200 ? '...' : '')}</span>
                                    </div>
                                </TitledGreyBox>
                                <br></br>
                            </div>
                        )))
                    }
                </>
            }
        </PageContentBlock>
    );
};
