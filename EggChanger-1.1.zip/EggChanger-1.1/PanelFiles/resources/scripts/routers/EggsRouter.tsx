import React from 'react';
import { NavLink, Route, RouteComponentProps, Switch } from 'react-router-dom';
import NavigationBar from '@/components/NavigationBar';
import NotFound from '@/components/screens/NotFound';
import TransitionRouter from '@/TransitionRouter';
import SubNavigation from '@/components/elements/SubNavigation';

import EggsContainer from '@/components/dashboard/eggs/EggsContainer';

export default ({ location }: RouteComponentProps) => (
    <>
        <NavigationBar/>
        <TransitionRouter>
            <Switch location={location}>
                <Route path={'/eggs'} component={EggsContainer} exact/>
                
                <Route path={'*'} component={NotFound}/>
            </Switch>
        </TransitionRouter>
    </>
);
