class GitSteamClass {
    constructor(element, menu) {
        this.element = element;
        this.menu = menu;
    }

    destroy() {
        this.element = undefined;
    }

    sanitizedString(value) {
        return $('<div>').text(value).html();
    }

    steamWorkshop(path) {
        swal({
            type: 'input',
            title: 'Workshop Download',
            text: 'Download workshop addon into the current directory.',
            showCancelButton: true,
            showConfirmButton: true,
            closeOnConfirm: false,
            showLoaderOnConfirm: true,
            inputPlaceholder: 'Workshop ID / Link'
        }, (val) => {
            if (val === false || val === '') {
                swal.close();
                return false;
            }

            $.ajax({
                type: 'POST',
                url: `${Pterodactyl.node.scheme}://${Pterodactyl.node.fqdn}:${Pterodactyl.node.daemonListen}/v1/server/downloader/steam`,
                headers: {
                    'X-Access-Token': Pterodactyl.server.daemonSecret,
                    'X-Access-Server': Pterodactyl.server.uuid,
                },
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify({
                    path: path,
                    workshop: val
                })
            }).done(data => {
                if (data.success == 'true') {
                    swal({
                        type: 'success',
                        title: 'Downloading done!',
                        html: true,
                        text: this.sanitizedString('Downloaded into folder.')
                    });

                    Files.list(path);
                } else {
                    swal({
                        type: 'error',
                        title: 'Whoops!',
                        html: true,
                        text: this.sanitizedString(data.error)
                    });
                }
            }).fail(jqXHR => {
                console.error(jqXHR);
                var error = 'An error occurred while trying to process this request.';
                if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                    error = jqXHR.responseJSON.error;
                }
                swal({
                    type: 'error',
                    title: 'Whoops!',
                    html: true,
                    text: this.sanitizedString(error)
                });
            });
        });
    }

    gitClone(path) {
        swal({
            type: 'input',
            title: 'Git Clone',
            text: 'Clone git repository into the current directory.',
            showCancelButton: true,
            showConfirmButton: true,
            closeOnConfirm: false,
            showLoaderOnConfirm: false,
            inputPlaceholder: 'Git URL'
        }, (val) => {
            if (val === false || val === '') {
                swal.close();
                return false;
            }

            swal({
                type: 'input',
                title: 'Branch',
                text: 'Which branch to clone, leave empty to default to master.',
                showCancelButton: true,
                showConfirmButton: true,
                closeOnConfirm: false,
                showLoaderOnConfirm: true,
                inputPlaceholder: 'Git Branch'
            }, (branch) => {
                if (branch === false) {
                    swal.close();
                    return false;
                }

                $.ajax({
                    type: 'POST',
                    url: `${Pterodactyl.node.scheme}://${Pterodactyl.node.fqdn}:${Pterodactyl.node.daemonListen}/v1/server/downloader/git/clone`,
                    headers: {
                        'X-Access-Token': Pterodactyl.server.daemonSecret,
                        'X-Access-Server': Pterodactyl.server.uuid,
                    },
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify({
                        path: path,
                        git: val,
                        branch: branch
                    })
                }).done(data => {
                    if (data.success == 'true') {
                        swal({
                            type: 'success',
                            title: 'Cloning done!',
                            html: true,
                            text: this.sanitizedString('Cloned into folder.')
                        });

                        Files.list(path);
                    } else {
                        swal({
                            type: 'error',
                            title: 'Whoops!',
                            html: true,
                            text: this.sanitizedString(data.error)
                        });
                    }
                }).fail(jqXHR => {
                    console.error(jqXHR);
                    var error = 'An error occurred while trying to process this request.';
                    if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                        error = jqXHR.responseJSON.error;
                    }
                    swal({
                        type: 'error',
                        title: 'Whoops!',
                        html: true,
                        text: this.sanitizedString(error)
                    });
                });
            });
        });
    }

    gitPull(path) {
        swal({
            type: 'warning',
            title: 'Git Pull',
            text: 'Pull the latest changes of a repository in current directory.',
            html: true,
            showCancelButton: true,
            showConfirmButton: true,
            closeOnConfirm: false,
            showLoaderOnConfirm: true
        }, () => {
            $.ajax({
                type: 'POST',
                url: `${Pterodactyl.node.scheme}://${Pterodactyl.node.fqdn}:${Pterodactyl.node.daemonListen}/v1/server/downloader/git/pull`,
                headers: {
                    'X-Access-Token': Pterodactyl.server.daemonSecret,
                    'X-Access-Server': Pterodactyl.server.uuid,
                },
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify({
                    path: path
                })
            }).done(data => {
                if (data.success == 'true') {
                    swal({
                        type: 'success',
                        title: 'Pulling done!',
                        html: true,
                        text: this.sanitizedString('Pulled into folder.')
                    });

                    Files.list(path);
                } else {
                    swal({
                        type: 'error',
                        title: 'Whoops!',
                        html: true,
                        text: this.sanitizedString(data.error)
                    });
                }
            }).fail(jqXHR => {
                console.error(jqXHR);
                var error = 'An error occurred while trying to process this request.';
                if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                    error = jqXHR.responseJSON.error;
                }
                swal({
                    type: 'error',
                    title: 'Whoops!',
                    html: true,
                    text: this.sanitizedString(error)
                });
            });
        });
    }
}

function openSteamMenu() {
    new GitSteamClass().steamWorkshop($('#file_listing').data('current-dir') || '/');
}

function openGitClone() {
    new GitSteamClass().gitClone($('#file_listing').data('current-dir') || '/');
}

function openGitPull() {
    new GitSteamClass().gitPull($('#file_listing').data('current-dir') || '/');
}
